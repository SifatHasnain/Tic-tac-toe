package com.example.sifat.connect3game;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    // 0: circle; 1: cross;

    int activePlayer;
    int tappedCounterNumber;
    boolean gameActive;
    String message;

    int[] gameState = new int[10];
    int[][] winningPositions = {{0, 1, 2}, {3, 4, 5}, {6, 7, 8}, {0, 3, 6}, {1, 4, 7}, {2, 5, 8}, {0, 4, 8}, {2, 4, 6}};

    public void defaultValues() {

        // 0: circle; 1: cross;
        activePlayer = 0;
        gameActive = true;
        tappedCounterNumber = 0;

        Toast.makeText(this, "Player 1 turn:", Toast.LENGTH_SHORT).show();

        for (int i = 0; i < gameState.length; i++) {
            gameState[i] = 2;
        }
    }

    public void dropIn(View view) {

        ImageView counter = (ImageView) view;

        int tappedCounter = Integer.parseInt(counter.getTag().toString());

        tappedCounterNumber++;

        if (gameState[tappedCounter] == 2 && gameActive) {

            counter.setTranslationY(-1000);

            gameState[tappedCounter] = activePlayer;

            if (activePlayer == 0) {

                activePlayer = 1;

                message = "Player 2";
                counter.setImageResource(R.drawable.circle);

            } else {

                activePlayer = 0;

                message = "Player 1";
                counter.setImageResource(R.drawable.cross);

            }

            counter.animate().translationYBy(1000).rotation(3600).setDuration(300);

            String result = "";
            int c = 0;

            for (int[] winningPos : winningPositions) {

                if (gameState[winningPos[0]] == gameState[winningPos[1]] && gameState[winningPos[1]] == gameState[winningPos[2]] && gameState[winningPos[0]] != 2) {

                    //Someone has won
                    String winner;

                    if (activePlayer == 0) {

                        winner = "Player 2";

                    } else {

                        winner = "Player 1";

                    }
                    c = 1;

                    result = winner + " has won!";

                    break;

                } else if (tappedCounterNumber == 9) {

                    c = 2;
                    result = "It's a tie!";

                }
            } if (c != 0) {

                gameActive = false;

                Button playAgainButton = (Button) findViewById(R.id.playAgainButton);
                TextView winnerTextView = (TextView) findViewById(R.id.winnerTextView);

                winnerTextView.setText(result);

                playAgainButton.setVisibility(View.VISIBLE);
                winnerTextView.setVisibility(View.VISIBLE);

            } else
                Toast.makeText(this, message + " turn:", Toast.LENGTH_SHORT).show();
        }
    }

    public void playAgain(View view) {

        Button playAgainButton = (Button) findViewById(R.id.playAgainButton);
        TextView winnerTextView = (TextView) findViewById(R.id.winnerTextView);

        playAgainButton.setVisibility(View.INVISIBLE);
        winnerTextView.setVisibility(View.INVISIBLE);

        GridLayout gridLayout = (GridLayout) findViewById(R.id.gridLayout);

        for (int i = 0; i < gridLayout.getChildCount(); i++) {

            ImageView counter = (ImageView) gridLayout.getChildAt(i);

            counter.setImageDrawable(null);

        }
        defaultValues();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        defaultValues();
    }
}